package com.example.recyclerview;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {
    String BASE_URL = "https://simplifiedcoding.net/demos/";
    @GET("marvel")
//    Call<ArrayList<Contact>> getSuperHeroes();
    Call<ArrayList<Contact>> getSuperHeroes();
}
