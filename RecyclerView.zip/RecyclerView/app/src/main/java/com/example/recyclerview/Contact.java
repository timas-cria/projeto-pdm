package com.example.recyclerview;

public class Contact {
    String name;
    String realname;
    String team;

    public Contact(String name, String realname, String team) {
        this.name = name;
        this.realname = realname;
        this.team = team;
    }
}
