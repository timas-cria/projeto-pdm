package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ArrayList<Contact> contacts;
//    ArrayList<Contact> heros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        contacts = new ArrayList<Contact>();
        getSuperHeroes();

        RecyclerView rvContatos = findViewById(R.id.rvContatos);
        MyAdapter adaptador = new MyAdapter(contacts);
        RecyclerView.LayoutManager layout =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rvContatos.setLayoutManager(layout);
        rvContatos.setAdapter(adaptador);
    }

    private void getSuperHeroes() {
        Call<ArrayList<Contact>> call = RetrofitClient.getInstance().getMyApi().getSuperHeroes();
        call.enqueue(new Callback<ArrayList<Contact>>() {
            @Override
            public void onResponse(Call<ArrayList<Contact>> call, Response<ArrayList<Contact>> response) {
                contacts = response.body();
                Log.d("MyApp", contacts.get(2).name.toString());
                Log.d("MyApp", contacts.get(2).realname.toString());
                Log.d("MyApp", contacts.get(2).team.toString());
                Log.d("MyApp", contacts.getClass().toString());

//                for (Contact hero : heros){
//                    contacts.add(hero);
//                }
//                String[] oneHeroes = new String[myHeroList.size()];
//                for (int i = 0; i < myHeroList.size(); i++) {
//                    oneHeroes[i] = myHeroList.get(i).getName();
//                }
//                superListView.setAdapter(new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, oneHeroes) );
            }

            @Override
            public void onFailure(Call<ArrayList<Contact>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Ocorreu um erro", Toast.LENGTH_LONG).show();
            }
        });
    }

    //instancia o objeto contato e adiciona ao ArrayList<Contato>
    private void criarContato(String nome, String realName, String team) {
        Contact contato = new Contact(nome, realName, team);
        contacts.add(contato);
    }
}