package com.example.recyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    ArrayList<Contact> contacts;

    public MyAdapter(ArrayList<Contact> contacts) {
        this.contacts = contacts;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView txtName;
        final TextView realname;
        final TextView txtExemple;

        public ViewHolder(View view) {
            super(view);
            txtName = (TextView) view.findViewById(R.id.txtNome);
            realname = (TextView) view.findViewById(R.id.txtRealname);
            txtExemple = (TextView) view.findViewById(R.id.txtTeam);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_contact, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contact contato = contacts.get(position);
        holder.txtName.setText(contato.name);
        holder.realname.setText(contato.realname);
        holder.txtExemple.setText(contato.team);
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }


}
